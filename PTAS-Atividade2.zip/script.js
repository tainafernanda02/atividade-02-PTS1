const express = require('express');
const app = express();


app.set('ejs');
app.engine('html', require('ejs').renderFile);
app.get('/',(req,res) => {
  res.render('script.ejs');
})
app.get('/noticias/01',(req,res) => {
  res.render('script.ejs');
})
app.get('/noticias',(req,res) => {
  res.render('noticia/script.ejs');
})